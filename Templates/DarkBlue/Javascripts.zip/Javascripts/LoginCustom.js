$(function() {
	$.EduceusLogin.WindowHeight();
    $.EduceusLogin.ApplyLoginForm();
});